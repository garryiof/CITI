Offline policy process demo (main + role views)
================================================

Open index.html in a browser (file://). No network required.

Main view: index.html
  - Intelligence lens → All roles (main view) stays here
  - Policy Follower / Compliance Officer / Policy Owner open role tabs

Role views: role_intelligence.html?lens=business_owner|compliance_officer|policy_owner
  - Same workflow BPMN as main, filtered per role

Included: app.js, styles.css, data.js, role_intelligence.*, vendor/, policy_source.html
